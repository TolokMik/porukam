<?php
		   /*
 * Copyright 2015 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this plugin and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
        $item = Item::newInstance()->findByPrimaryKey(Params::getParam('itemId'));
       $category_fee = ModelRbc::newInstance()->getPremiumPrice_rbc($item['fk_i_category_id']);
                if($category_fee > 0) {
                ?>
                 <div style="text-align:left;">
                  <label style="font-weight: bold;"><?php _e("Item's title", 'rbc'); ?>:</label> <?php echo $item['s_title']; ?><br/>
                        <label style="font-weight: bold;"><?php _e("Item's description", 'rbc'); ?>:</label> <?php echo $item['s_description']; ?><br/>
                    </div>
                 <div style="display:inline-block; width:100%;">					
                    <div style="float:left; width:49%; border: solid 1px black; ">
					<h1><?php _e('Premium', 'rbc'); ?></h1>
<div class="rbc" style="background:#FF5D13 repeat-x scroll 0px 0px; width:90px;"><h2 style="color:#FFF;padding-left:3px;"><?php _e('20x views!', 'rbc'); ?></h2></div>
<p><?php _e('Premium status is when the ads are highlighted and shown on top of free ads in . This promotes more rapid sales. The duration of the option in days:', 'rbc'); ?><?php echo osc_get_preference('premium_days', 'rbc'); ?></p>
                        <?php _e("In order to make premium your ad , it's required to pay a fee", 'rbc'); ?>.<br/>
						<?php echo sprintf(__("The current fee for this category is: %.2f %s", 'rbc'), $category_fee, osc_get_preference('currency', 'rbc')); ?><br/>
						 <?php if(osc_is_web_user_logged_in()) {
                                $wallet = ModelRbc::newInstance()->getWallet_rbc(osc_logged_user_id());
								$summ = isset($wallet['f_outsum'])?$wallet['f_outsum']:null;
                                if($summ>=$category_fee) {
                                    rbc_button($category_fee, sprintf(__("Premium fee for item %d", "rbc"), $item['pk_i_id']), $item['pk_i_id'], osc_logged_user_id(),1,__("Make Premium", "rbc"));
                              } else {
                                        Robokassa::button($category_fee, sprintf(__("Premium fee for item %d", "rbc"), $item['pk_i_id']), $item['pk_i_id'], osc_logged_user_id(),1,__("Make Premium", "rbc"));
                                }
                        } else {
Robokassa::button($category_fee, sprintf(__("Premium fee for item %d", "rbc"), $item['pk_i_id']), $item['pk_i_id'], osc_user_id(),1,__("Make Premium", "rbc"));
} ?>
                    </div>
        
                <?php
                } 

$category_fee1 = ModelRbc::newInstance()->getColorPrice_rbc($item['fk_i_category_id']);
    if ($category_fee1 > 0) {
        ?>
   
            <div style="float:right; width:49%; border: solid 1px black; ">
			<h1><?php _e('Highlight', 'rbc'); ?></h1>
<div class="rbc" style="background:#1AAF5D repeat-x scroll 0px 0px; width:90px;"><h2 style="color:#FFF;padding-left:3px;"><?php _e('5x views!', 'rbc'); ?></h2></div>
<p><?php _e('This option allows to attract the visitors attention on you ads. Background of your ad becomes highlighted. The duration of the option in days:', 'rbc'); ?><?php echo osc_get_preference('color_days', 'rbc'); ?></p>
                <?php _e("In order to Highlight your ad , it's required to pay a fee", 'rbc'); ?>.<br/>
                <?php echo sprintf(__("The current fee for this category is: %.2f %s", 'rbc'), $category_fee1, osc_get_preference('currency', 'rbc')); ?>
                <br/>
		<?php if(osc_is_web_user_logged_in()) {
                                $wallet = ModelRbc::newInstance()->getWallet_rbc(osc_logged_user_id());
								$summ = isset($wallet['f_outsum'])?$wallet['f_outsum']:null;
                                if($summ>=$category_fee1) {
                                    rbc_button($category_fee1, sprintf(__("Highlight fee for item %d", "rbc"), $item['pk_i_id']), $item['pk_i_id'], osc_logged_user_id(),3, __("Highlight", "rbc"));
                        
                                } else { 
									   Robokassa::button($category_fee1, sprintf(__("Highlight fee for item %d", "rbc"), $item['pk_i_id']), $item['pk_i_id'], osc_logged_user_id(),3, __("Highlight", "rbc"));

                                } 
								}else {
                                        Robokassa::button($category_fee1, sprintf(__("Highlight fee for item %d", "rbc"), $item['pk_i_id']), $item['pk_i_id'], osc_user_id(),3, __("Highlight", "rbc"));

                                }?>
             <div style="clear:both;"></div>
			</div>

			</div>
			<div style="text-align:center;">
          <a href="<?php echo osc_base_url(); ?>">
                        <button><?php _e('No, Thanks', 'rbc'); ?></button>
                    </a></div>
	
    <?php
    } 



?>