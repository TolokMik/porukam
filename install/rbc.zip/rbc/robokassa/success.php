<?php
		   /*
 * Copyright 2015 osclass-pro.com and osclass-pro.ru
 *
 * You shall not distribute this plugin and any its files (except third-party libraries) to third parties.
 * Rental, leasing, sale and any other form of distribution are not allowed and are strictly forbidden.
 */
if (isset($_POST['SignatureValue'])) {
    $mrhPass1 = osc_get_preference('mrhpass1', 'rbc');
    $outSumm = $_POST['OutSum'];
    $invId = $_POST['InvId'];
	$type = $_REQUEST["shp_product"];
	$shpBype = $_REQUEST["shp_item"];
	$userid = $_REQUEST["shp_user"];
    $signature = $_POST['SignatureValue'];

    $signature = strtoupper($signature);
    $mySignature = strtoupper(md5("$outSumm:$invId:$mrhPass1:shp_item=$shpBype:shp_product=$type:shp_user=$userid"));
    if ($mySignature != $signature) {
        echo "bad sign\n";
        exit();
    }

    if ($type == 1) {
        if (ModelRbc::newInstance()->premiumFeeIsPaid_rbc($shpBype)) {
		 osc_add_flash_ok_message(__('Payment processed correctly', 'rbc'));
		 $item = Item::newInstance()->findByPrimaryKey($shpBype);
		 $category = Category::newInstance()->findByPrimaryKey($item['fk_i_category_id']);
         View::newInstance()->_exportVariableToView('category', $category);
		 rbc_js_redirect_to(osc_search_category_url());
        }
    } elseif ($type == 2) {
         osc_add_flash_ok_message(__('Payment processed correctly', 'rbc'));
		 rbc_js_redirect_to(osc_search_category_url());

    } elseif ($type == 3) {
         osc_add_flash_ok_message(__('Payment processed correctly', 'rbc'));
		 rbc_js_redirect_to(osc_search_category_url());
    }
	elseif ($type == 4) {
         osc_add_flash_ok_message(__('Payment processed correctly', 'rbc'));
		 rbc_js_redirect_to(osc_search_category_url());
    }
	elseif ($type == 5) {
		 osc_add_flash_ok_message(__('Payment processed correctly', 'rbc'));
		 rbc_js_redirect_to(osc_route_url('rbc-user-pack'));
    }
	 else {
         osc_add_flash_error_message(__("There was a problem processing your Payment. Please contact the administrators",'rbc'));
		 if(osc_is_web_user_logged_in()) {
                    rbc_js_redirect_to(osc_route_url('rbc-user-menu'));
                } else {
                    View::newInstance()->_exportVariableToView('item', Item::newInstance()->findByPrimaryKey($shpBype));
                    rbc_js_redirect_to(osc_item_url());
                }
        }
}
?>

<script type="text/javascript">

</script>






