<?php

mdh_current_plugin_path("classes/Madhouse/Messenger/Controllers/Ajax.php");
$do = new Madhouse_Messenger_Controllers_Ajax();
$do->doModel();

?>