<?php Madhouse_Utils_Plugins::overrideView(); ?>
<link rel="stylesheet" type="text/css" href="<?php echo mdh_current_plugin_url("assets/css/web.css"); ?>" />
<div class="messenger">
    <h2><?php _e("Inbox", mdh_current_plugin_name()); ?></h2>
    <div class="wrapper">
        <ul class="unstyled inline filters">
            <li class="<?php echo (Params::getParam("filter") === "all" || Params::getParam("filter") == "") ? "active" : ""; ?>">
                <a href="<?php echo mdh_messenger_inbox_url(null, null, "all"); ?>">
                    <?php _e("All", "frigow"); ?>
                </a></li>
            <li class="<?php echo (Params::getParam("filter") === "unread") ? "active" : ""; ?>">
                <a href="<?php echo mdh_messenger_inbox_url(null, null, "unread"); ?>">
                    <?php _e("Unread", "frigow"); ?>
                </a>
            </li>
        </ul>

        <?php

            $params = array('total'              => (int) ceil(mdh_count_threads() / Params::getParam("n")),
                            'selected'           => (int) Params::getParam("p") - 1,
                            'class_prev'         => 'prev',
                            'class_next'         => 'next',
                            'class_selected'     => 'active',
                            'url'                => mdh_messenger_inbox_url('{PAGE}', Params::getParam("n"), Params::getParam("filter"))) ;
            $pagination = new Pagination($params);
        ?>
        <div class="pagination">
            <?php echo $pagination->doPagination(); ?>
        </div>
        <div class="showing-results">
            <?php echo mdh_pagination_from(Params::getParam("p"), Params::getParam("n")); ?>
            &nbsp;&ndash;&nbsp;
            <?php echo mdh_pagination_to(Params::getParam("p"), Params::getParam("n"), mdh_count_threads()); ?>
            &nbsp;<?php _e("on", "frigow"); ?>&nbsp;
            <?php echo mdh_count_threads(); ?>
        </div>
        <div class="clear"></div>
        <?php if(mdh_count_threads()): ?>
            <ul class="unstyled threads">
                <?php while(mdh_has_threads()): ?>
                    <li class="thread content <?php echo (mdh_thread_has_unread()) ? "has-unread": ""; ?>">
                        <ul class="unstyled">
                            <li class="last-activity">
                                <a href="<?php echo mdh_thread_url(); ?>">
                                    <em><?php echo mdh_thread_formatted_last_activity(); ?></em><br />
                                    <?php if(mdh_thread_has_status()): ?>
                                        <span class="status status-<?php echo mdh_thread_status_name(); ?>">
                                            <?php echo mdh_thread_status_title(); ?>
                                        </span>
                                    <?php endif; ?>
                                </a>
                            </li>
                            <li class="title">
                                <a href="<?php echo mdh_thread_url(); ?>">
                                    <?php if(mdh_thread_has_unread()): ?>
                                        <strong>
                                            <?php
                                                printf(
                                                    "%s (%d)",
                                                    (mdh_thread_title()) ? mdh_thread_title() : implode(", ", array_map(function($u) { return $u->getName(); }, mdh_thread_users())),
                                                    mdh_thread_count_unread()
                                                );
                                            ?>
                                        </strong>
                                    <?php else: ?>
                                        <strong><?php echo implode(", ", array_map(function($u) { return $u->getName(); }, mdh_thread_users())); ?></strong>
                                    <?php endif; ?>
                                    <p><?php echo mdh_thread_excerpt(); ?></p>
                                </a>
                            </li>
                            <li class="item">
                                <?php if(
                                        mdh_thread_had_item() ||
                                        (mdh_thread_has_item() && osc_item_is_expired()) ||
                                        (mdh_thread_has_item() && function_exists("mdh_moreedit_is_archived") && mdh_moreedit_is_archived()) ||
                                        (mdh_thread_has_item() && function_exists("mdh_moreedit_is_stopped") && mdh_moreedit_is_stopped())
                                    ):
                                ?>
                                    <em><?php _e("A deleted/disabled ad", mdh_current_plugin_name()); ?></em>
                                <?php elseif(mdh_thread_has_item() && (osc_item_is_spam() || ! osc_item_is_enabled() || ! osc_item_is_active())): ?>
                                    <em><?php _e("A blocked/spam ad", mdh_current_plugin_name()); ?></em>
                                <?php elseif(mdh_thread_has_item()): ?>
                                    <a href="<?php echo osc_item_url(); ?>">
                                        <?php echo osc_item_title(); ?><br />
                                        <?php echo osc_item_city(); ?>,&nbsp;<?php echo osc_item_formated_price(); ?>
                                    </a>
                                <?php else: ?>
                                    <em><?php _e("No item linked to this thread.", mdh_current_plugin_name()); ?></em>
                                <?php endif; ?>
                            </li>
                        </ul>
                        <div class="clear"></div>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p style="text-align: center; font-size: 1.2em; color: #666;">
                <?php _e("No messages, yet.", mdh_current_plugin_name()); ?>
            </p>
        <?php endif; ?>
    </div>
</div>