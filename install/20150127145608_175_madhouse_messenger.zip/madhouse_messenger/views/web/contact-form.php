<form action="<?php echo mdh_messenger_send_url(); ?>" method="post" name="contact_form">
    <?php if(osc_is_ad_page() || osc_is_item_contact_page()): ?>
        <?php ContactForm::primary_input_hidden(); ?>
        <input type="hidden" name="recipients[]" value="<?php echo osc_item_user_id(); ?>" />
    <?php else: ?>
        <input type="hidden" name="recipients[]" value="<?php echo osc_user_id(); ?>" />
    <?php endif; ?>

    <div class="control-group">
        <div class="controls">
            <?php if(mdh_messenger_is_contacted()): ?>
                <div class="wrapper-flash">
                    <div class="flashmessage flashmessage-info">
                        <?php _e("Already contacted : ", mdh_current_plugin_name()); ?><a style="color: #fff;" href="<?php echo mdh_thread_url(); ?>"><?php _e('see thread', mdh_current_plugin_name()) ; ?></a>.
                    </div>
                </div>
            <?php endif; ?>
            <textarea name="message" rows="10" placeholder="<?php _e("Write something...", mdh_current_plugin_name())?>"></textarea>
        </div>
    </div>
    <div class="control-group">
    	<div class="controls">
    		<button type="submit">
                <?php _e('Send message', mdh_current_plugin_name()) ; ?>
            </button>
    	</div>
    </div>
</form>