<?php

	/**
	 * Messenger base URL. Returns the base URL for frontend (web) calls.
	 * @return a string.
	 * @since 1.20 - Now using osclass routes.
	 *        1.01 - This function was added.
	 */
	function mdh_messenger_ajax_url() {
		return osc_route_ajax_url(mdh_current_plugin_name() . "_ajax");
	}

	/**
     * Messenger inbox URL. Returns the messenger inbox URL (opt. with the page number).
	 * @param $page the page number (int) to display
	 * @return a string.
	 * @since 1.01
	 */
	function mdh_messenger_inbox_url($page=null, $num=null, $filter=null) {
	    $params = array("p" => $page);
	    if(! is_null($num)) {
	        $params["n"] = $num;
	    }
	    if(! is_null($filter)) {
	        $params["filter"] = $filter;
	    }

		return osc_route_url(mdh_current_plugin_name() . "_inbox", $params);
	}

	/**
	 * Messenger URL for a particular thread.
	 * @param $threadId the id of the thread to point to.
	 * @return a string.
	 * @since 1.20
	 */
	function mdh_messenger_thread_url($threadId=null)
	{
	    //return mdh_messenger_ajax_url() . "&do=message&id=" . $threadId;
	    return osc_route_url(mdh_current_plugin_name() . "_thread", array("id" => $threadId));
	}

	/**
	 * Messenger send URL. Returns the URL to call to send a message.
	 * @return a string.
	 * @since 1.01
	 */
	function mdh_messenger_send_url() {
		//return mdh_messenger_ajax_url() . "&do=send";
		return osc_route_url(mdh_current_plugin_name() . "_send");
	}

	/**
	 * Includes the messenger widget.
	 *
	 * The messenger widget is a component generally located in the header navigation
	 * bar which consists in :
	 *     - Giving a quick-access link to the messenger inbox.
	 *     - Displaying the number of unread messages of the current user.
	 *     - Giving a quick-access to the last threads of the current user.
	 *
	 * Makes AJAX call to get those informations.
	 *
	 * Think of it as a copycat of the Facebook widget that you all know.
	 *
	 * @return void
	 * @see Madhouse_Messenger_Controllers_Web::doModel - case "widget".
	 * @since 1.20 Since then, a default widget is loaded if none is found in the theme.
	 *        1.00
	 */
	function mdh_messenger_widget() {
	    Madhouse_Utils_Controllers::doViewPart("widget.php");
	}

	/**
	 * Includes the messenger contact form.
	 *
	 * That's the form you need when contacting someone from an item (see item.php
	 * or item-contact.php). Loads the default contact form if none is found in the
	 * theme.
	 *
	 * @return void
	 * @see Madhouse_Messenger_Controllers_Web::doModel - case "send".
	 * @since 1.20
	 */
	function mdh_messenger_contact_form() {
    	Madhouse_Utils_Controllers::doViewPart("contact-form.php");
	}

	/**
	 * Tells if the current user or item has already been contacted. Exports the thread if it exists.
	 * @return true if a thread already exists, false otherwise.
	 * @since 1.20
	 */
    function mdh_messenger_is_contacted() {
        if(is_null(osc_item_id())) {
            // Is user contacted ?
            $e = Madhouse_Messenger_Models_Threads::newInstance()->findByUsers(osc_logged_user_id(), osc_item_user_id());
            if($e) {
    	        View::newInstance()->_exportVariableToView("mdh_thread", $e);
    	        return true;
    	    }
    	    return false;
        } else {
            // Is item contacted ?
            if(! osc_item_user_id()) {
                return false;
            }

            $e = Madhouse_Messenger_Models_Threads::newInstance()->findByUsers(osc_logged_user_id(), osc_item_user_id(), osc_item_id());
            if($e) {
                View::newInstance()->_exportVariableToView("mdh_thread", $e);
                return true;
            }
            return false;
        }
    }

    /**
     * Are the status enabled ?
     * @return true/false.
     * @since 1.20
     */
    function mdh_messenger_status_enabled()
    {
        return osc_get_preference("enable_status", mdh_current_preferences_section());
    }

    /**
     * Returns the default status id.
     * @return int.
     * @since 1.20
     */
    function mdh_messenger_default_status()
    {
        return osc_get_preference("default_status", mdh_current_preferences_section());
    }

    /**
     * Is the status only editable for item owners ?
     * @return true/false.
     * @since 1.20
     */
    function mdh_messenger_status_for_owner()
    {
        return osc_get_preference("status_for_owner_only", mdh_current_preferences_section());
    }

	// HELPERS for Inbox.

    /**
     * Returns true if the current page is a messenger page.
     * @return true/false
     * @since 1.20
     */
    function mdh_is_messenger()
    {
        return mdh_messenger_is_inbox();
    }

    /**
     * Returns true if the current page is a messenger page.
     * @return true/false
     * @since 1.00
     * @deprecated use mdh_is_messenger() instead.
     */
	function mdh_messenger_is_inbox() {
	    $rewrite = Rewrite::newInstance();
	    if(
	        ($rewrite->get_location() == 'ajax' && Params::getParam("ajaxfile") == mdh_current_plugin_name() . "/main.php")
	        ||
            preg_match('/^' . mdh_current_plugin_name() . '_.*$/', Params::getParam("route"))
	    ) {
	        return true;
	    }
		return false;
	}

?>