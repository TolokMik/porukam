<?php 

class Madhouse_Messenger_NoValidRecipientsException extends Exception
{
    // Nothing.
}

?>