<?php 

class Madhouse_Messenger_EmptyMessageException extends Exception
{
    // Nothing.
}

?>