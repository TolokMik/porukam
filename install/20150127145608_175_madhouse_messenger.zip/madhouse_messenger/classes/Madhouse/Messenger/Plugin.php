<?php

/**
 * Madhouse Messenger class.
 * @since  1.30
 */
class Madhouse_Messenger_Plugin
{
	public static function install()
	{
		// TODO.
	}

	public static function uninstall()
	{
		// TODO.
	}

	/**
	 * Upgrades the model & preferences to 1.30.
	 * @return void
	 * @since  1.30
	 */
	public static function upgrade130()
	{
		if(mdh_get_preference("version") === "") {
			// Imports new SQL model.
			mdh_import_sql(mdh_current_plugin_path("assets/model/upgrade-130.sql", false));

			// Auto-messages.
			osc_set_preference('automessage_item_deleted', '1', mdh_current_preferences_section(), 'BOOLEAN');
			osc_set_preference('automessage_item_spammed', '1', mdh_current_preferences_section(), 'BOOLEAN');
			osc_set_preference('automessage_newer_days', '30', mdh_current_preferences_section(), 'INTEGER');

			// URL rewriting
		    osc_set_preference('base_url', 'messenger', mdh_current_preferences_section(), 'STRING');

			// New preferences for emails.
			osc_set_preference('email_excerpt_length', '45', mdh_current_preferences_section(), 'INTEGER');
	    	osc_set_preference('email_excerpt_oneline', '0', mdh_current_preferences_section(), 'BOOLEAN');

			// New preferences for reminders.
			osc_set_preference('reminder_every_days', '2', mdh_current_preferences_section(), 'INTEGER');
	    	osc_set_preference('stop_reminder_after', '8', mdh_current_preferences_section(), 'INTEGER');

	    	// We just upgraded to 1.30. Tag it.
			osc_set_preference("version", "1.30", mdh_current_preferences_section());
		}
	}
}

?>