<?php 

class Madhouse_Messenger_NotSentException extends Exception
{
    // Nothing.
}

?>