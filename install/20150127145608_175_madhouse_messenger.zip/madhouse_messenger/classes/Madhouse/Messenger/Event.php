<?php

class Madhouse_Messenger_Event extends Madhouse_NamedEntity
{

	/**
	 * Locales of this event.
	 * @var Array
	 * @since 1.30
	 */
	protected $locale;

    /**
	 * Construct.
	 *		Use static method create() instead.
	 */
	public function __construct($id, $name, $locale)
	{
        $this->id = $id;
		$this->name = $name;
		$this->locale = $locale;
	}

	/**
	 * Returns the $locale locale or the current user's locale description of this event.
	 * @param  String $locale Locale code (ex. en_US).
	 *                        If not given, the user current locale is used.
	 * @return String         The text of this event (localized).
	 */
	public function getText($locale=null) {
		if(is_null($locale)) {
			$locale = osc_current_user_locale();
		}
		return osc_field($this->toArray(), "s_text", $locale);
	}

}

?>