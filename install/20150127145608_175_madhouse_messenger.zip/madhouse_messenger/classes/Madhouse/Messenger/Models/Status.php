<?php

class Madhouse_Messenger_Models_Status extends DAO
{
	/**
	 * Singleton.
	 */
	private static $instance;

	/**
	 * Singleton constructor.
	 * @return an MadhouseMessengerDAO object.
	 */
	public static function newInstance()
	{
		if(!self::$instance instanceof self) {
			self::$instance = new self;
		}
		return self::$instance;
	}

    public function __construct()
    {
        parent::__construct();
        $this->setTableName('t_mmessenger_status');
        $this->setFields(array("id", "name"));
        $this->setPrimaryKey("id");
    }

    public function getDescriptionTableName()
    {
        return $this->getTablePrefix() . 't_mmessenger_status_description';
    }

    /**
     * Finds a status by its id.
     * @params $id the status unique identifier (primary key)
     * @returns MadhouseMessengerStatus object.
     * @throws Exception if something went wrong.
     * @since 1.10
     */
    public function findByPrimaryKey($id)
    {
        $status = parent::findByPrimaryKey($id);
        if($status === false) {
            throw new Madhouse_NoResultsException(
                sprintf("Element '%d' not found in table '%s'", $id, $this->getTableName())
            );
        }
        return $this->buildObject($status);
    }

    public function listAll()
    {
        $dao = $this;
        return array_map(
            function($v) use ($dao) {
                return $dao->buildObject($v);
            },
            parent::listAll()
        );
    }

    public function buildObject($o)
    {
        return new Madhouse_Messenger_Status(
            $o["id"],
            $o["name"],
            Madhouse_Utils_Models::extendData(
                $this,
                $this->getDescriptionTableName(),
                "fk_i_status_id",
                $o
            )
        );
    }
}

?>