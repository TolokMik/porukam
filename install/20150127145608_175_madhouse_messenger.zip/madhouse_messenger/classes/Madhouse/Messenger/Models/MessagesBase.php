<?php 

abstract class Madhouse_Messenger_Models_MessagesBase extends DAO
{
    /**
     * Save the message in database.
     *     (Don't send it, just save its content/sender/status/event/etc)
     * @param $datas array of data
     * @param $thread (optional) thread to attach the message to.
     * @return the id of the message.
     * @throws Madhouse_QueryFailedException, if something goes wrong inserting/updating.
     * @since 1.22
     */
    protected function save($datas, $thread=null)
    {   
        // Insert the message.
    	$isInserted = parent::insert($datas);
    	if(!$isInserted) {
    		throw new Madhouse_QueryFailedException(__("Saving the message has failed.", mdh_current_plugin_name()));
    	}
    	
    	// Gets the last inserted id (our message id).
    	$messageId = $this->dao->insertedId();
        
        if(is_null($thread)) {
            $rootId = $messageId;
        } else {
            $rootId = $thread->getId();
        }
        
    	// Update the message to set its root.
    	$isUpdated = $this->updateByPrimaryKey(
    		array(
    			"root_id" => $rootId
    		),
    		$messageId
    	);
    	if(!$isUpdated) {
    		throw new Madhouse_QueryFailedException(__("Adding the message to the requested thread has failed.", mdh_current_plugin_name()));
    	}
    	
        return $messageId;
    }
}

?>