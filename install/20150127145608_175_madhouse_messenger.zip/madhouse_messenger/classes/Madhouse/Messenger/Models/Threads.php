<?php

/**
 *
 *
 *
 * @since 1.10
 */
class Madhouse_Messenger_Models_Threads extends Madhouse_Messenger_Models_MessagesBase
{
	/**
	 * Singleton.
	 */
	private static $instance;

    public $messagesDAO;
    public $recipientsDAO;

	/**
	 * Singleton constructor.
	 * @return an MadhouseMessengerDAO object.
	 */
	public static function newInstance()
	{
		if(!self::$instance instanceof self) {
			self::$instance = new self;
		}
		return self::$instance;
	}

    public function __construct()
    {
        parent::__construct();
        $this->setTableName('t_mmessenger_message');
        $this->setPrimaryKey("id");
        $this->setFields(array("id", "title", "content", "sentOn", "hidden", "reported", "root_id", "sender_id", "status_id", "event_id", "item_id"));

        $this->messagesDAO = Madhouse_Messenger_Models_Messages::newInstance();
        $this->recipientsDAO = Madhouse_Messenger_Models_Recipients::newInstance();
    }

    /**
     * Returns the list of selected fields used in find* methods.
     * - Beware, tables aliases must match.
     * - It allows to not repeat that long list of fields all over that buildObject method needs.
     * @return a string.
     * @since 1.22
     */
    private static function selectedFields()
    {
        return "t.*, last.max AS last_id, l.content AS last_content, l.sentOn AS last_sentOn, l.hidden AS last_hidden, l.root_id AS last_root_id, l.sender_id AS last_sender_id, l.status_id AS last_status_id, l.event_id AS last_event_id, l.item_id AS last_item_id, l.reported AS last_reported, total.count as t_count";
    }

    /**
     * Gets a particular thread for an id, with paginated list of messages.
     * @param $threadId id of the requested thread.
     * @param $page (opt., default to 1) page requested.
     * @param $max  (opt., default to 10) number of messages per page.
     * @return array of threads (Madhouse_Messenger_Threads).
     * @throws Madhouse_NoResultsException, if the thread does not exists.
     * @since 1.00
     */
    public function findByPrimaryKey($threadId) {
    	return Madhouse_Utils_Models::get(
            $this,
    		sprintf("SELECT %s
    				 FROM %s r
    				 JOIN (SELECT MAX(id) AS max, root_id
    				 	   FROM %s
     	           		   WHERE root_id = %d
    				 	   GROUP BY root_id
    				 	   ) last
    				 	ON r.message_id = last.max
    				 JOIN %s t
    				 	ON t.id = last.root_id
    				 JOIN %s l
    				    ON l.id = last.max
        			 JOIN (
        			     SELECT COUNT(1) as count, tm.root_id
        			     FROM %s tm
        			     GROUP BY tm.root_id
        			 ) total
        			     ON total.root_id = t.id
    				 ORDER BY last.max DESC",
    				 self::selectedFields(),
    				 $this->recipientsDAO->getTableName(),
    				 $this->messagesDAO->getTableName(),
    				 $threadId,
    				 $this->messagesDAO->getTableName(),
    				 $this->messagesDAO->getTableName(),
    				 $this->messagesDAO->getTableName()
    		),
            function($r, $dao) {
                return $dao->buildObject($r->row());
            }
    	);
    }

    /**
     * Returns the threads of a given user $user, paginated ($n-th, from page $page).
     * @param $user user that wants his list of threads.
     * @param $page (opt., default to 1) page requested.
     * @param $n    (opt., default to 10) number of threads per page.
     * @return an array of threads (Madhouse_Messenger_Threads),
     *         OR an empty array if none found (no exceptions thrown).
     * @since 1.00
     */
    /*
        SELECT t.id, last.max, u.count, total.count
        FROM oc_t_mmessenger_recipients lr
        JOIN (SELECT MAX(im.id) AS max, im.root_id
                FROM oc_t_mmessenger_message im
                GROUP BY root_id
        ) last ON lr.message_id = last.max
        JOIN oc_t_mmessenger_message t ON last.root_id = t.id
        JOIN oc_t_mmessenger_message l ON l.id = last.max
        JOIN (SELECT COUNT(1) as count, um.root_id as u_root_id FROM oc_t_mmessenger_recipients ur JOIN oc_t_mmessenger_message um ON um.id = ur.message_id WHERE ur.readOn IS NULL AND ur.recipient_id = 5 GROUP BY um.root_id) u ON u.u_root_id = t.id
        JOIN (SELECT COUNT(1) as count, tm.root_id as t_root_id FROM oc_t_mmessenger_message tm GROUP BY tm.root_id) total ON total.t_root_id = t.id
        GROUP BY t.id
        ORDER BY last.max DESC;
        */
    public function findByUser($user, $page=1, $n=10, $unread=false)
    {
        return Madhouse_Utils_Models::get(
            $this,
        	sprintf("SELECT %s
        			 FROM %s r
        			 JOIN (
        			     SELECT MAX(im.id) AS max, im.root_id
        			     FROM %s im
        			     GROUP BY root_id
        			 ) last ON r.message_id = last.max
        			 JOIN %s t ON last.root_id = t.id
        			 JOIN %s l ON l.id = last.max
        			 JOIN (
        			     SELECT COUNT(1) as count, tm.root_id as t_root_id
        			     FROM %s tm
        			     GROUP BY tm.root_id
        			 ) total ON total.t_root_id = t.id
        			 %s
        			 GROUP BY l.root_id
        			 ORDER BY last.max DESC
        			 LIMIT %d, %d",
        			 (
                        (! $unread) ?
                            self::selectedFields()
                        :
                            sprintf("%s, unread.count as u_count", self::selectedFields())
                     ),
    				 $this->recipientsDAO->getTableName(),
    				 $this->messagesDAO->getTableName(),
    				 $this->messagesDAO->getTableName(),
    				 $this->messagesDAO->getTableName(),
                     $this->messagesDAO->getTableName(),
                     (
                        ($unread) ?
                            sprintf(
                                "JOIN (
                                    SELECT COUNT(1) as count, um.root_id
                                    FROM %s ur
                                    JOIN %s um ON um.id = ur.message_id
                                    WHERE ur.readOn IS NULL AND ur.recipient_id = %s
                                    GROUP BY um.root_id
                                ) unread ON unread.root_id = t.id",
                                $this->recipientsDAO->getTableName(),
                                $this->messagesDAO->getTableName(),
                                $user->getId()
                            )
                        :
                            sprintf("WHERE (r.recipient_id = %d OR l.sender_id = %d)", $user->getId(), $user->getId())
                     ),
        			 (($page-1) * $n),
        			 $n
        	),
            function($r, $dao) {
                return array_map(
                    function($v) use ($dao) {
                        // Build an object from the array.
                        return $dao->buildObject($v);
                    },
                    $r->result()
                );
            },
            false,
            array()
        );
    }

    public function findByItem($item, $page=1, $n=10)
    {
        return Madhouse_Utils_Models::get(
            $this,
            sprintf("SELECT %s
                     FROM %s r
                     JOIN (
                         SELECT MAX(im.id) AS max, im.root_id
                         FROM %s im
                         GROUP BY root_id
                     ) last ON r.message_id = last.max
                     JOIN %s t ON last.root_id = t.id
                     JOIN %s l ON l.id = last.max
                     JOIN (
                         SELECT COUNT(1) as count, tm.root_id as t_root_id
                         FROM %s tm
                         GROUP BY tm.root_id
                     ) total ON total.t_root_id = t.id
                     %s
                     GROUP BY l.root_id
                     ORDER BY last.max DESC
                     LIMIT %d, %d",
                     (
                        (! $unread) ?
                            self::selectedFields()
                        :
                            sprintf("%s, unread.count as u_count", self::selectedFields())
                     ),
                     $this->recipientsDAO->getTableName(),
                     $this->messagesDAO->getTableName(),
                     $this->messagesDAO->getTableName(),
                     $this->messagesDAO->getTableName(),
                     $this->messagesDAO->getTableName(),
                     sprintf("WHERE t.item_id = %d", $item->getId()),
                     (($page-1) * $n),
                     $n
            ),
            function($r, $dao) {
                return array_map(
                    function($v) use ($dao) {
                        // Build an object from the array.
                        return $dao->buildObject($v);
                    },
                    $r->result()
                );
            },
            false,
            array()
        );
    }

    /**
     * Finds the thread started by $user1 and $user2 (opt. about item $itemId).
     * @param $user1 the user that sent the first message.
     * @param $user2 the user that received the second message.
     * @param $itemId (default null) the id of the item linked to the thread.
     * @return the thread (Madhouse_Messenger_Thread).
     * @since 1.00
     */
    public function findByUsers($user1, $user2, $itemId=null)
    {
        if(is_null($itemId)) {
            $itemId = 0;
        }

    	return Madhouse_Utils_Models::get(
    	    $this,
    	    sprintf("SELECT %s
    	    		 FROM %s r
    	    		 JOIN (SELECT MAX(im.id) AS max, im.root_id
    	    		 	   FROM %s im
    	    		 	   GROUP BY root_id
    	    		 	   ) last
    	    		 	ON r.message_id = last.max
    	    		 JOIN %s t
    	    		 	ON t.id = last.root_id
    	    		 JOIN %s l
    	    		    ON l.id = last.max
    	    		 JOIN %s rt
    	    		    ON rt.message_id = t.id
    	    		JOIN (SELECT COUNT(1) as count, tm.root_id as t_root_id FROM %s tm GROUP BY tm.root_id) total ON total.t_root_id = t.id
    	    		 WHERE ((rt.recipient_id = %d AND t.sender_id = %d) OR (rt.recipient_id = %d AND t.sender_id = %d)) AND t.item_id = %d
    	    		 GROUP BY l.root_id
    	    		 ORDER BY last.max DESC",
    	    		 self::selectedFields(),
                    $this->recipientsDAO->getTableName(),
                    $this->messagesDAO->getTableName(),
                    $this->messagesDAO->getTableName(),
                    $this->messagesDAO->getTableName(),
                    $this->recipientsDAO->getTableName(),
                    $this->messagesDAO->getTableName(),
                    $user2,
                    $user1,
                    $user1,
                    $user2,
                    $itemId
    	    ),
    	    function($r, $dao) {
    	        return $dao->buildObject($r->row());
    	    },
    	    false
    	);
    }

    /**
     * Counts the number (total) of threads for a user.
     * @param $userId id of the user.
     * @returns an int.
     */
    public function countByUser($user, $unread=false) {
        return Madhouse_Utils_Models::get(
            $this,
            sprintf("SELECT COUNT(1) AS count
            		 FROM (
            	        SELECT m.id
            		 	FROM %s r
            		 	JOIN %s m ON m.id = r.message_id
            		 	%s
            		 	GROUP BY m.root_id
            		 ) t",
            		 $this->recipientsDAO->getTableName(),
            		 $this->messagesDAO->getTableName(),
            		 (
                        ($unread) ?
                            sprintf(
                                "JOIN (
                                    SELECT COUNT(1) as count, um.root_id
                                    FROM %s ur
                                    JOIN %s um ON um.id = ur.message_id
                                    WHERE ur.readOn IS NULL AND ur.recipient_id = %s
                                    GROUP BY um.root_id
                                ) unread ON unread.root_id = m.root_id",
                                $this->recipientsDAO->getTableName(),
                                $this->messagesDAO->getTableName(),
                                $user->getId()
                            )
                        :
                            sprintf("WHERE (r.recipient_id = %d OR m.sender_id = %d)", $user->getId(), $user->getId())
                     )
            ),
            function($r, $dao) { return $r->rowObject()->count; }
        );
    }

    /**
     * Counts the total number of threads.
     * @return an int.
     * @since 1.20
     */
    public function count()
    {
        return Madhouse_Utils_Models::countWhere($this, "root_id = id");
    }

    /**
     * Counts the number of threads created today.
     * @return an int.
     * @since 1.20
     */
    public function countToday() {
        return Madhouse_Utils_Models::countToday($this, "sentOn", "root_id = id");
    }

    /**
     * Counts the number of threads created yesterday.
     * @return an int.
     * @since 1.20
     */
    public function countYesterday() {
        return Madhouse_Utils_Models::countYesterday($this, "sentOn", "root_id = id");
    }

    /**
     * Counts the number of threads created this week.
     * @return an int.
     * @since 1.20
     */
    public function countThisWeek()
    {
        return Madhouse_Utils_Models::countThisWeek($this, "sentOn", "root_id = id");
    }

    /**
     * Counts the number of threads created last week.
     * @return an int.
     * @since 1.20
     */
    public function countLastWeek()
    {
        return Madhouse_Utils_Models::countLastWeek($this, "sentOn", "root_id = id");
    }

    /**
     * Counts the number of threads created this month.
     * @return an int.
     * @since 1.20
     */
    public function countThisMonth()
    {
        return Madhouse_Utils_Models::countThisMonth($this, "sentOn", "root_id = id");
    }

    /**
     * Counts the number of threads created last month.
     * @return an int.
     * @since 1.20
     */
    public function countLastMonth()
    {
        return Madhouse_Utils_Models::countLastMonth($this, "sentOn", "root_id = id");
    }

	/**
	 * Creates (inserts) a new thread for users with a first message.
	 * TODO
	 * @returns the id of the newly created message.
	 */
	public function create($message, $itemId=null)
	{
	    $statusId = null;
	    if(mdh_messenger_status_enabled() && mdh_messenger_default_status() != 0) {
            $statusId = mdh_messenger_default_status();
	    }

		// Insert the message.
		$messageId = $this->save(array(
			"content" => $message->getContent(),
			"sender_id" => $message->getSender()->getId(),
			"sentOn" => date("Y-m-d H:i:s"),
			"item_id" => $itemId,
			"status_id" => $statusId
		));

        // Sends the message to everyone in the thread.
        $this->recipientsDAO->send($messageId, $message->getRecipients());

        // Get an updated version of the thread.
		return $this->findByPrimaryKey($messageId, 1, 1);
	}

    /**
     * Updates the status of a thread.
     * @param $thread (MadhouseMessengerThread) thread that needs his status changed.
     * @param $status (MadhouseMessengerStatus) the new status of the thread.
     * @return the number of updated rows.
     */
    public function updateStatus($thread, $status) {
    	if(! $thread->hasStatus() || ($thread->hasStatus() && $thread->getStatus()->getId() != $status->getId())) {
    	    // Perform the SQL query.
        	if($this->updateByPrimaryKey(array("status_id" => $status->getId()), $thread->getId()) == 0) {
        	    throw new Exception(sprintf("Setting status '%d' for thread '%d' has failed", $status->getId(), $thread->getId()));
        	}
        }
    }

	/**
	 * Returns the thread object for an SQL result set.
	 * @param $row associative array of all the infos about the thread (as returned by $this->dao->get().
	 * @returns MadhouseMessengerThread object.
	 */
	public function buildObject($row)
	{
	    // Build the last message of this thread.
    	$lastMessage = $this->messagesDAO->buildObject(
    	    array(
    	        "id" => $row["last_id"],
    	        "content" => $row["last_content"],
    	        "sentOn" => $row["last_sentOn"],
    	        "hidden" => $row["last_hidden"],
       	        "reported" => $row["last_reported"],
    	        "sender_id" => $row["last_sender_id"],
    	        "root_id" => $row["last_root_id"],
    	        "status_id" => $row["last_status_id"],
    	        "event_id" => $row["last_event_id"],
    	        "item_id" => $row["last_item_id"],
    	    ),
    	    self::buildSkeleton($row)
    	);

        // Build a ThreadSummary object.
        $thread = self::extendObject(
            new Madhouse_Messenger_ThreadSummary(
                $row["id"],
                $lastMessage,
                $row["t_count"]
            ),
            $row
        );

        // Extends informations and return.
		return $thread;
	}

	/**
	 * Builds a skeleton of threads.
	 * @param $row the associative array of data for the thread.
	 * @return Madhouse_Messenger_ThreadSkeleton object.
	 * @since 1.20
	 */
	public static function buildSkeleton($row)
	{
	    $thread = new Madhouse_Messenger_ThreadSkeleton($row["id"]);
		return self::extendObject($thread, $row);
	}

	/**
	 * Extends (completes) the thread with optional fields (title, item, status).
	 * @param $thread the thread to complete.
	 * @param $row the associative array of data for the thread.
	 * @return Madhouse_Messenger_ThreadSkeleton object.
	 * @since 1.20
	 */
    private static function extendObject($thread, $row)
    {
        // Sets the title of the thread if it has any.
		if(isset($row["title"]) && !empty($row["title"])) {
			$thread->withTitle($row["title"]);
		}

		if(isset($row["item_id"]) && $row["item_id"] != 0) {
			// An item is linked or has been linked and is not anymore.
			$item = Item::newInstance()->findByPrimaryKey($row["item_id"]);
			if(count($item) == 0) {
				// An item has been linked but is not anymore.
				$thread->withItem(-1);
			} else {
				// An item is linked and still exists.
				$thread->withItem(
					Madhouse_Item::create(
						$item,
						ItemResource::newInstance()->getResource($row["item_id"])
					)
				);
			}
		} else if(isset($row["item_id"]) && $row["item_id"] == 0) {
			// No item is linked and never has been.
			$thread->withItem(NULL);
		}

		if(isset($row["status_id"]) && !empty($row["status_id"])) {
			$thread->withStatus(Madhouse_Messenger_Models_Status::newInstance()->findByPrimaryKey($row["status_id"]));
		}

		return $thread;
    }
}

?>