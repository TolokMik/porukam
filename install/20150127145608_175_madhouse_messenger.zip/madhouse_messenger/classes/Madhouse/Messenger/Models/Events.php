<?php

/**
 *
 *
 *
 * @since 1.10
 */
class Madhouse_Messenger_Models_Events extends DAO
{
	/**
	 * Singleton.
	 */
	private static $instance;

	/**
	 * Singleton constructor.
	 * @return an MadhouseMessengerDAO object.
	 */
	public static function newInstance()
	{
		if(!self::$instance instanceof self) {
			self::$instance = new self;
		}
		return self::$instance;
	}

    public function __construct()
    {
        parent::__construct();
        $this->setTableName('t_mmessenger_events');
        $this->setFields(array("id", "name"));
        $this->setPrimaryKey("id");
    }

    public function getDescriptionTableName()
    {
        return $this->getTablePrefix() . 't_mmessenger_events_description';
    }

    /**
     * Finds an event by its id.
     * @params $id the event unique identifier (primary key)
     * @returns MadhouseMessengerEvent object.
     * @throws Exception if something went wrong.
     * @since 1.10
     */
    public function findByPrimaryKey($id)
    {
        $event = parent::findByPrimaryKey($id);
        if($event === false) {
            throw new Madhouse_NoResultsException(
                sprintf("Event '%d' not found in table '%s'", $id, $this->getTableName())
            );
        }
        return $this->buildObject($event);
    }

    /**
     * Finds an event by name.
     * @param $name name of the event that we're looking for.
     * @returns MadhouseMessengerEvent object.
     * @throws Exception if no event is found for $name name.
     * @see Madhouse_Utils_Models::findByName
     * @since 1.10
     */
    public function findByName($name)
    {
        return $this->buildObject(Madhouse_Utils_Models::findByField($this, "name", $name));
    }

    /**
     * Build (constitute) the object that will be returned to controllers/views.
     * @param $e associative array that contains data to create the event.
     * @returns MadhouseMessengerEvent object.
     * @since 1.10
     */
    private function buildObject($e)
    {
        return new Madhouse_Messenger_Event(
            $e["id"],
            $e["name"],
            Madhouse_Utils_Models::extendData(
                $this,
                $this->getDescriptionTableName(),
                "fk_i_event_id",
                $e
            )
        );
    }
}

?>