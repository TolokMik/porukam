<?php

class Madhouse_Messenger_Status extends Madhouse_NamedEntity
{
	protected $locale;

    /**
     * Constructor.
     * @param $id UID of this status.
     * @param $name name of this status.
     */
	function __construct($id, $name, $locale) {
		$this->id = $id;
		$this->name = $name;
		$this->locale = $locale;
	}

	public function getTitle($locale=null) {
		if(is_null($locale)) {
			$locale = osc_current_user_locale();
		}
		return osc_field($this->_toArray(), "s_title", $locale);
	}

    /**
     * Returns the translated text for this status.
     * @return String
     * @since 1.00
     *        1.30 - text is now in the database.
     */
	public function getText($locale=null) {
		if(is_null($locale)) {
			$locale = osc_current_user_locale();
		}
		return osc_field($this->_toArray(), "s_text", $locale);
	}

	private function _toArray()
	{
		return parent::toArray();
	}

	public function toArray()
	{
		return array_merge(
			parent::toArray(),
			array(
				"s_title" => $this->getTitle(),
				"s_text" => $this->getText()
			)
		);
	}
}

?>