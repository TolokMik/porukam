
CREATE TABLE IF NOT EXISTS /*TABLE_PREFIX*/t_mmessenger_status_description (
	`fk_i_status_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`fk_c_locale_code` CHAR(5) NOT NULL,
	`s_title` VARCHAR(50) NOT NULL,
	`s_text` text,
  	PRIMARY KEY (`fk_i_status_id`,`fk_c_locale_code`),
  	CONSTRAINT `fk_/*TABLE_PREFIX*/t_mmessenger_status_desc` FOREIGN KEY(`fk_i_status_id`) REFERENCES `/*TABLE_PREFIX*/t_mmessenger_status`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
  	CONSTRAINT `fk_/*TABLE_PREFIX*/t_mmessenger_status_locale` FOREIGN KEY (`fk_c_locale_code`) REFERENCES `/*TABLE_PREFIX*/t_locale`(`pk_c_code`)
) ENGINE = InnoDB DEFAULT CHARACTER SET 'UTF8' COLLATE 'UTF8_GENERAL_CI';

INSERT IGNORE INTO /*TABLE_PREFIX*/t_mmessenger_status_description(`fk_i_status_id`, `fk_c_locale_code`, `s_title`, `s_text`)
   SELECT id, 'en_US', 'Processing', 'Your inquiry is getting processed.'
   FROM `oc_t_mmessenger_status` e
   WHERE e.name = 'processing';
INSERT IGNORE INTO /*TABLE_PREFIX*/t_mmessenger_status_description(`fk_i_status_id`, `fk_c_locale_code`, `s_title`, `s_text`)
   SELECT id, 'en_US', 'Scheduled', 'An appointment/shipment has been scheduled.'
   FROM `oc_t_mmessenger_status` e
   WHERE e.name = 'scheduled';
INSERT IGNORE INTO /*TABLE_PREFIX*/t_mmessenger_status_description(`fk_i_status_id`, `fk_c_locale_code`, `s_title`, `s_text`)
   SELECT id, 'en_US', 'Accepted', 'Item owner has accepted your offer.'
   FROM `oc_t_mmessenger_status` e
   WHERE e.name = 'accepted';
INSERT IGNORE INTO /*TABLE_PREFIX*/t_mmessenger_status_description(`fk_i_status_id`, `fk_c_locale_code`, `s_title`, `s_text`)
   SELECT id, 'en_US', 'Refused', 'Item owner is not interested.'
   FROM `oc_t_mmessenger_status` e
   WHERE e.name = 'refused';

CREATE TABLE IF NOT EXISTS /*TABLE_PREFIX*/t_mmessenger_events_description (
	`fk_i_event_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`fk_c_locale_code` CHAR(5) NOT NULL,
	`s_text` text,
  	PRIMARY KEY (`fk_i_event_id`,`fk_c_locale_code`),
  	CONSTRAINT `fk_/*TABLE_PREFIX*/t_mmessenger_events_desc` FOREIGN KEY(`fk_i_event_id`) REFERENCES `/*TABLE_PREFIX*/t_mmessenger_events`(`id`) ON UPDATE CASCADE ON DELETE CASCADE,
  	CONSTRAINT `fk_/*TABLE_PREFIX*/t_mmessenger_events_locale` FOREIGN KEY (`fk_c_locale_code`) REFERENCES `/*TABLE_PREFIX*/t_locale`(`pk_c_code`)
) ENGINE = InnoDB DEFAULT CHARACTER SET 'UTF8' COLLATE 'UTF8_GENERAL_CI';

INSERT IGNORE INTO /*TABLE_PREFIX*/t_mmessenger_events (`name`)
VALUES
	('item_deleted'),
  ('item_spammed');

INSERT IGNORE INTO /*TABLE_PREFIX*/t_mmessenger_events_description(`fk_i_event_id`, `fk_c_locale_code`, `s_text`)
   SELECT id, 'en_US', 'Status of this thread has changed to {STATUS_NAME}'
   FROM `oc_t_mmessenger_events` e
   WHERE e.name = 'status_change';
INSERT IGNORE INTO /*TABLE_PREFIX*/t_mmessenger_events_description(`fk_i_event_id`, `fk_c_locale_code`, `s_text`)
   SELECT id, 'en_US', 'Item linked to this thread is not available anymore: advertiser might have found what he/she was looking for'
   FROM `oc_t_mmessenger_events` e
   WHERE e.name = 'item_deleted';
INSERT IGNORE INTO /*TABLE_PREFIX*/t_mmessenger_events_description(`fk_i_event_id`, `fk_c_locale_code`, `s_text`)
   SELECT id, 'en_US', 'Item linked to this thread has been marked as spam by an admin'
   FROM `oc_t_mmessenger_events` e
   WHERE e.name = 'item_spammed';

