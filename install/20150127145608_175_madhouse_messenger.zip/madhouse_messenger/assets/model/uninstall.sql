DROP TABLE IF EXISTS `/*TABLE_PREFIX*/t_mmessenger_recipients`;
DROP TABLE IF EXISTS `/*TABLE_PREFIX*/t_mmessenger_message`;
DROP TABLE IF EXISTS `/*TABLE_PREFIX*/t_mmessenger_events_description`;
DROP TABLE IF EXISTS `/*TABLE_PREFIX*/t_mmessenger_events`;
DROP TABLE IF EXISTS `/*TABLE_PREFIX*/t_mmessenger_status_description`;
DROP TABLE IF EXISTS `/*TABLE_PREFIX*/t_mmessenger_status`;
